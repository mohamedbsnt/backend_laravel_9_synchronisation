<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\ProductController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('welcome');
});

// Affichage de la liste des produits importés
Route::get('admin/products', [ProductController::class, 'index'])
     ->name('admin.products.index');

// Import des produits depuis l’API externe
Route::post('admin/products/import', [ProductController::class, 'import'])
     ->name('admin.products.import');
