<?php
namespace App\Services;

use GuzzleHttp\Client;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class GoogleTokenService
{
    private Client $client;
    
    public function __construct()
    {
        $this->client = new Client(['timeout' => 30]);
    }
    
    public function getValidAccessToken(): string
    {
        return Cache::remember('google_access_token', 3500, function () {
            return $this->refreshAccessToken();
        });
    }
    
    private function refreshAccessToken(): string
    {
        try {
            $response = $this->client->post('https://oauth2.googleapis.com/token', [
                'form_params' => [
                    'client_id' => config('services.google_merchant.client_id'),
                    'client_secret' => config('services.google_merchant.client_secret'),
                    'refresh_token' => config('services.google_merchant.refresh_token'),
                    'grant_type' => 'refresh_token',
                ]
            ]);
            
            $data = json_decode($response->getBody(), true);
            
            Log::info('Google access token refreshed successfully');
            
            return $data['access_token'];
            
        } catch (\Exception $e) {
            Log::error('Failed to refresh Google token: ' . $e->getMessage());
            throw $e;
        }
    }
}
