<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use GuzzleHttp\Client;

class GenerateGoogleTokens extends Command
{
    protected $signature = 'google:tokens';
    protected $description = 'Generate Google OAuth tokens for Merchant API';

    public function handle()
    {
        $clientId = env('GOOGLE_CLIENT_ID');
        $clientSecret = env('GOOGLE_CLIENT_SECRET');
        
        if (!$clientId || !$clientSecret) {
            $this->error('❌ GOOGLE_CLIENT_ID et GOOGLE_CLIENT_SECRET requis dans .env');
            return;
        }

        // Étape 1: URL d'autorisation
        $scopes = [
            'https://www.googleapis.com/auth/content',
            'https://www.googleapis.com/auth/content.readonly'
        ];
        
        $authUrl = 'https://accounts.google.com/o/oauth2/auth?' . http_build_query([
            'client_id' => $clientId,
            'redirect_uri' => 'https://medhant.devaito.com/auth/google/callback',
            'scope' => implode(' ', $scopes),
            'response_type' => 'code',
            'access_type' => 'offline',
            'prompt' => 'consent'
        ]);

        $this->info('🔗 Ouvrez cette URL dans votre navigateur:');
        $this->line($authUrl);
        $this->newLine();
        
        $authCode = $this->ask('📝 Collez le code d\'autorisation reçu');
        
        if (!$authCode) {
            $this->error('❌ Code d\'autorisation requis');
            return;
        }

        // Étape 2: Échanger le code contre les tokens
        try {
            $client = new Client();
            $response = $client->post('https://oauth2.googleapis.com/token', [
                'form_params' => [
                    'client_id' => $clientId,
                    'client_secret' => $clientSecret,
                    'redirect_uri' => 'https://medhant.devaito.com/auth/google/callback',
                    'grant_type' => 'authorization_code',
                    'code' => $authCode,
                ]
            ]);

            $tokens = json_decode($response->getBody(), true);
            
            $this->info('✅ Tokens générés avec succès!');
            $this->newLine();
            $this->info('📋 Ajoutez ces lignes à votre .env:');
            $this->line("GOOGLE_ACCESS_TOKEN={$tokens['access_token']}");
            $this->line("GOOGLE_REFRESH_TOKEN={$tokens['refresh_token']}");
            
        } catch (\Exception $e) {
            $this->error('❌ Erreur: ' . $e->getMessage());
        }
    }
}
