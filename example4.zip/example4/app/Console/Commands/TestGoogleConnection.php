<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use GuzzleHttp\Client;

class TestGoogleConnection extends Command
{
    protected $signature = 'google:test';
    protected $description = 'Test Google Merchant API connection';

    public function handle()
    {
        try {
            $client = new Client();
            $response = $client->get(
                "https://shoppingcontent.googleapis.com/content/v2.1/merchants/" . env('GOOGLE_MERCHANT_ID'),
                [
                    'headers' => [
                        'Authorization' => 'Bearer ' . env('GOOGLE_ACCESS_TOKEN'),
                        'Accept' => 'application/json',
                    ]
                ]
            );
            
            $data = json_decode($response->getBody(), true);
            
            $this->info('✅ Connexion Google Merchant réussie!');
            $this->info('📊 Compte: ' . ($data['name'] ?? 'N/A'));
            $this->info('🌐 Site web: ' . ($data['websiteUrl'] ?? 'N/A'));
            
        } catch (\Exception $e) {
            $this->error('❌ Erreur de connexion: ' . $e->getMessage());
            
            if (strpos($e->getMessage(), 'invalid_grant') !== false) {
                $this->warn('💡 Token expiré, regénérez-le avec: php artisan google:tokens');
            }
        }
    }
}
